export default function Page() {
    return <p>Invoices Page</p>;
  }