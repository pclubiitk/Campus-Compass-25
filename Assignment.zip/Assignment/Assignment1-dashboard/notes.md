Deployed at `https://campus-compass-25-seven.vercel.app/dashboard`.

